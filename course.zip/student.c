#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief  This function adds grades to a students grade array
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  // This checks if it is the first grade being added to the student grade array
  // If so, it allocates 1 memory to it
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  // If it is not the first grade being added, it uses realloc to accomodate the new grade that is to be added
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  // this adds the new grade to the grade array
  student->grades[student->num_grades - 1] = grade;
}
/**
 * @brief this function finds the total grade average of a student
 * 
 * @param student 
 * @return double 
 */
double average(Student* student)
{ // if the student has no grades, it returns an average of a 0
  if (student->num_grades == 0) return 0;
 // otherwise, a variable total is created 
  double total = 0;
  // this for loop iterates thru all of the students grades and adds it to the total variable each time
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  // this divides the sum of all the grades by the number of grades available
  return total / ((double) student->num_grades);
}

/**
 * @brief takes the student names, id, num_grades and prints them. It finds the average and prints the students average as well. 
 * 
 * @param student 
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  // this for loops iterates through all the grades a student has and prints them
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
 
/**
 * @brief This function generates a random student 
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades)
{ // array of first names
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};
// array fo last names
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]); // picks a random first name
  strcpy(new_student->last_name, last_names[rand() % 24]); // picks a random last name
 
 // this for loop iterates 10 times and creates a  student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); 
  new_student->id[10] = '\0';

 // This for loop iterates through the number of grades given in the function and produces random grades
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student; // this returns a student with a random first name/ last name,id and grades.
}