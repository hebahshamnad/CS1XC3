/**
 * @file course.c
 * @author Sharmin Ahmed (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>


/**
 * @brief Takes in a course and a student and enrolls the student into the course
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  // If there is only one student then it allocates 1 memory to it
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  //If it is not the first student being added, it uses realloc to accomodate the new student that is to be added
  {
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  // this adds the new student to the student array
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief takes the course name, code and number of students and prints them neatly
 * 
 * @param course 
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @brief  This function finds the student with the highest average and then returns the student with that average
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{ // if the  course has no students, return nothing
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
 
  // this loop iterated through all the students and compares their average with the students before them 
  // until the student with the highest average is found
  
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 * @brief Find the students who are passing by iterating through the averages of every student and checking if they are greater than 50. 
 *        It returns an array of every student that is passing. 
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  // This for loop iterates through the student's averages and checks if it is greater than or equal to 50. 
  // If the average is passing, it increments the count variable by 1 

  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student)); //passing is an array with the size of the count variable

  int j = 0;
  // This for loop iterates through the total number of students and checks for passing avergaes.
  // if the averages are passing, it will be added to the passing array

  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;
 // returns an array of passing students
  return passing;
}